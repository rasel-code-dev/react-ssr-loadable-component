import React, { useEffect, useRef } from 'react'
import './DummyPage.scss'
import CreateFood from '../components/createFood'
import { Row, Container, Col, Box } from '../components/Layout'
import Input from '../components/Form/Input/Input'

import NavBar from './NavBar'

import Joi from '@hapi/joi'

const DummyPage = (props)=>{

  const [state, setTest] = React.useState({
    test: { value: "", tauched: false, errorMessage: '' }, 
    test2: { value: "", tauched: false, errorMessage: '' },
    test3: { value: "", tauched: false, errorMessage: '' }
  })

  function generateErrorMessage(name, value){
    const schema = Joi.object({
      test: Joi
      .string()
      .alphanum()
      .min(3)
      .max(30)
      .required(),
      test2: Joi
      .string()
      .alphanum()
      .min(3)
      .max(30)
      .required(),
      test3: Joi
      .string()
      .alphanum()
      .min(3)
      .max(30)
      .required(),
    })

    let result = schema.validate({[name]: value}, { abortEarly: false })  
    console.log(result);
    
    let errors = {}
    if(result.error){ 
      result.error.details.map(err=>{
        if(err.path[0] === name ){
          errors[name] = err.message 
        }
      })
    }  
    return errors  
  }

  function handleChange(name, value){

    let errors = generateErrorMessage(name, value)

    setTest({
      ...state,
      [name]: {
        ...state[name],
        tauched: true,
        value: value,
        errorMessage:  errors[name] && errors[name]
      }
    })
  } 

  function handleBlur(e){
    const { name } = e.target
    setTest({
      ...state,
      [name]: {
        ...state[name],
        tauched: true,
      }
    })
  }
  function handleClick(e){
    const { name } = e.target
    setTest({
      ...state,
      [name]: {
        ...state[name],
        tauched: true,
      }
    })
  }
  


  return (
    <div className="">
      <Input 
        size="lg"
        name="test" 
        label='Username' 
        value={state.test.value} 
        error={state.test.errorMessage}
        tauched={state.test.tauched}
        onBlur={handleBlur} 
        onClick={handleClick} 
        onChange={handleChange} 
      />
      <Input 
        size="md"
        name="test2" 
        label='Username' 
        value={state.test2.value} 
        error={state.test2.errorMessage}
        tauched={state.test2.tauched}
        onBlur={handleBlur} 
        onClick={handleClick} 
        onChange={handleChange} 
      />
      <Input 
        size="sm"
        name="test3" 
        label='Username' 
        value={state.test3.value} 
        error={state.test3.errorMessage}
        tauched={state.test3.tauched}
        onBlur={handleBlur} 
        onClick={handleClick} 
        onChange={handleChange} 
      />
    </div>
  )
}




export default DummyPage







// scroll slider...............

// import React, { useEffect, useRef } from 'react'

// import './DummyPage.scss'
// import CreateFood from '../components/createFood'
// import { Row, Container, Col, Box } from '../components/Layout'
// import Button from '../components/Button/Button'

// import p1 from '../asserts/images/Alec Thompson card.jpg'
// import p2 from '../asserts/images/Gina Andrew card.jpg'
// import p3 from '../asserts/images/avatar-1.jpg'
// import p4 from '../asserts/images/lenovo-ideapad-ip-s145-14iwl-8th-gen-intel-core-11568622443.jpg'
// import p5 from '../asserts/images/s145-14iwl-1-500x500.jpg'
// import range from '../utils/range'

// const images = [p1, p2, p3, p4, p5]


// class DummyPage extends React.Component{  

//   slider = React.createRef(null)

//   state = {
//     currentImage: 1,
//     totalImage: 0,
//     scrollLeft: 0,
//     totalScrollWidth: 0,
//     currentImageScrollWidth: 0,
//   }


//   componentDidMount() {
//     console.log("component Did Mount");
//     if(this.slider){
//       let totalScrollWidth = this.slider.current.scrollWidth
//       let imagesDiv =  this.slider.current.children

//       this.setState({ 
//         totalScrollWidth, 
//         currentImageScrollWidth: totalScrollWidth, 
//         totalImage: imagesDiv.length
//       })    
//     }
//   }


//   handlePrevImage=(e)=>{
//     const { currentImage, totalImage, scrollLeft, currentImageScrollWidth } = this.state
//     if(currentImage !== 1){
//       this.setState({
//         currentImage: currentImage - 1, 
//         scrollLeft: Math.abs(scrollLeft - currentImageScrollWidth)
//       })
  
//       if(this.slider)
//         this.slider.current.scrollLeft =  Math.abs(scrollLeft - currentImageScrollWidth)
      
//     } else{
//       this.setState({
//         currentImage: totalImage, 
//         scrollLeft: currentImageScrollWidth * totalImage
//       })
  
//       if(this.slider)
//         this.slider.current.scrollLeft = currentImageScrollWidth * totalImage
//     }
//   }

//   handleNextImage=(e)=>{
//     const { currentImage, totalImage, scrollLeft, currentImageScrollWidth } = this.state
//     if(totalImage > currentImage ){
//       this.setState({
//         currentImage: currentImage + 1, 
//         scrollLeft: scrollLeft + currentImageScrollWidth
//       })
  
//       if(this.slider){
//         if(this.state.scrollLeft === 0 ){
//           this.slider.current.scrollLeft = currentImageScrollWidth
//         }else{
//           this.slider.current.scrollLeft = scrollLeft + currentImageScrollWidth
//         }
//       }
//     }else{
//       this.setState({
//         currentImage: 1, 
//         scrollLeft: 0
//       })
  
//       if(this.slider)
//         this.slider.current.scrollLeft = 0
      
//     }
//   }
//   // console.log(state);
  
//   render(){


//   const items = range(this.state.totalImage)
    
//   console.log("render method.......");
  

//   return (
//     <Container fluid >
//       <div className="slider_wrapper">
//         <div onClick={this.handlePrevImage} className="prev_image"><i class="fa fa-chevron-circle-left" aria-hidden="true"></i></div>
//         <div ref={this.slider} className="slider">
//           { images.map(image=>{
//             return (
//               <div className="image" key={image}>
//                 <img src={image} />
//               </div>
//             )
//           }) }
//         </div>
//         <div className="items">
//           {items.map(item=>(
//             <li className={["item_bullet", this.state.currentImage == item ? "active" : ""].join(" ")}  key={item} ></li>
//           ))}
//         </div>
//         <div onClick={this.handleNextImage} className="next_image"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i></div>
//       </div>
//     </Container>
//   )
// }
// }



// export default DummyPage
