import React, { useRef, useEffect } from "react";
import classnames from "classnames";
import "./Input.scss";

const Input = (props) => {
  let {
    size,
    theme,
    placeholder,
    label,
    as,
    value,
    name,
    type = "text",
    onChange,
    onBlur,
    onClick,
    error,
    tauched
  } = props;

  const [isFocused, setFocus] = React.useState(false);
  const [isShowPass, setShowPass] = React.useState(false);
  const [renderShowPass, setRenderShowPass] = React.useState(false);
  const [lastErrorMessage, setLastErrorMessage] = React.useState("");

  const input = React.createRef();

  const prevErrorRef = useRef();
  React.useEffect(() => {
    if (prevErrorRef.current) {    
      setLastErrorMessage(prevErrorRef.current.innerHTML);
    }
  }, [error]);

  function showInputHandler(e) {
    setFocus(true);
    input && input.current.focus();
  }

  const handleBlur = e => {
    onBlur && onBlur(e)
    if (input) {
      if (!input.current.value ) {
        setFocus(false);
        
      }
    }
  };

  const showPassword = e => {
    setShowPass(!isShowPass);
  };

  let groupClasses = classnames("input_group", size && size, theme && `input_group_${theme}`);

  function onChang(e) {
    if (e.target.name === "password") {
      if (e.target.value) {
        setRenderShowPass(true);
      } else {
        setRenderShowPass(false);
      }
    }
    onChange && onChange(e.target.name, e.target.value);
  }
  
  function handleClick(e){
    onClick && onClick(e)
  }
    

  return (
    <div onClick={showInputHandler} className={groupClasses}>
      <label
        className={[
          isFocused || value ? "expand_label" : "collapse_label",
          error && tauched ? "error_label" : "",
          error && !value && !isFocused ?  "collapse_error_label" : "",
          size && `label-${size}`
        ].join(" ")}
        htmlFor={name}
      >
        {label}
      </label>

      <div className="input_wrapper">
        <div
          ref={prevErrorRef}
          className={[
            "error_message",
            error && tauched ? "show_error_message" : "hide_error_message",
            error && !value && !isFocused ?  "collapse_show_error_message" : ""
          ].join(" ")}
        >
          {error || lastErrorMessage}
        </div>
        <input
          placeholder={placeholder}
          ref={input}
          value={value}
          onChange={onChang}
          onBlur={handleBlur}
          onClick={handleClick}
          className={[
            isFocused || value ? "expand_input" : "collapse_input"
          ].join(" ")}
          type={type === "password" ? (isShowPass ? "text" : type) : type}
          name={name}
        />

        {as === "password" && renderShowPass && (
          <div onClick={showPassword} className="show_password_icon">
            <i
              className={["far", isShowPass ? "fa-eye-slash" : "fa-eye"].join(
                " "
              )}
            />
          </div>
        )}
        <span
          className={[
            "input_border",
            tauched && isFocused ? "expand_input_border" : "",
            tauched && !isFocused ?  "collapse_input_border" : "",
            error ? "input_border_error" : ''
          ].join(" ")}
        />
      </div>
    </div>
  );
}

export default Input;
