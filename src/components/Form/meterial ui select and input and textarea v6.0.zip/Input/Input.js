
import React,  { useRef, useEffect } from 'react'
import classnames from 'classnames'
import './Input.scss'



const Input = (props)=>{
  let { theme, label, as, value, name, type="text", onChange, onBlur, error, tauched } = props

  const [isFocused, setFocus] = React.useState(false)
  const [isShowPass, setShowPass] = React.useState(false)
  const [renderShowPass, setRenderShowPass] = React.useState(false)
  const [lastErrorMessage, setLastErrorMessage] = React.useState('')

  const input = React.createRef()


  const prevErrorRef = useRef()
  React.useEffect(() => {
    if( prevErrorRef.current){
      setLastErrorMessage(prevErrorRef.current.innerHTML);
    }
  }, [error])

  function showInputHandler(e){
    setFocus(true)
    if(input){
      input.current.focus()      
    }
  }

  const handleBlur=(e)=>{
    onBlur(e)
    if(input){
      if(!input.current.value && !error && !tauched){
        setFocus(false)
      }     
    }
  }

  const showPassword=(e)=>{
    setShowPass(!isShowPass)
  }

  let groupClasses = classnames("input_group", theme && `input_group_${theme}`) 

  function onChang(e){
    if(e.target.name === 'password'){
      if(e.target.value){
        setRenderShowPass(true)
      }else{
        setRenderShowPass(false)
      }
    }
    onChange(e.target.name, e.target.value)
  }  


  // console.log(prevState(error));
  

  return(
    <div onClick={showInputHandler} className={groupClasses}>

      <label 
        className={[isFocused || value ? 'expand_label' : 'collapse_label', error && tauched ? 'error_label' : ''].join(" ")} 
        htmlFor={name}>{label}
      </label>
  

      <div className="input_wrapper">
        <div ref={prevErrorRef}  className={["error_message", error && tauched ? 'show_error_message' : 'hide_error_message'].join(" ")}>{ error || lastErrorMessage }</div>
        <input 
          ref={input}
          value={value}
          onChange={onChang}
          onBlur={handleBlur}
          className={[isFocused || value ? 'expand_input' : 'collapse_input'].join(" ")} 
          type={ type === 'password' ? isShowPass ? 'text' : type  : type} 
          name={name}
        />

        {as === 'password' && renderShowPass &&  (  
          <div onClick={showPassword} className="show_password_icon">
            <i className={['far', isShowPass ? 'fa-eye-slash' : 'fa-eye'].join(" ")}></i>
          </div>  
        )} 
        <span className={["input_border", isFocused || value ? "expand_input_border" : "collapse_input_border"].join(' ')}></span>
      </div>
    </div> 
  )
}

export default Input