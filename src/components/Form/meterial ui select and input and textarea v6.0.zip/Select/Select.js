import React, { useRef, useEffect} from 'react'
import classnames from 'classnames'

import './Select.scss'

const Select = (props) => {
  const { name, label, value, theme, type="text", id, className, error, tauched, onChange, onBlur, options=[] } = props

  const [ isSuggetion, setSuggetion ]  = React.useState(false)
  const [isFocused, setFocus] = React.useState(false)
  const [lastErrorMessage, setLastErrorMessage] = React.useState('')

  const input = React.createRef()
  const component = useRef(null)
  const prevErrorRef = useRef()

  useEffect(()=>{
    if(prevErrorRef.current){
      setLastErrorMessage(prevErrorRef.current.innerHTML);
    }
  }, [error])

  useEffect(()=>{
    window.addEventListener("click", handleClickOutSide, true)
    return ()=>{
      window.removeEventListener('click', handleClickOutSide, true)
    }
  }, [0])

  function onChang(e){
    console.log(e.target.name);
    
    onChange(e.target.name, e.target.value)
  }

  function handleClickOutSide(e){
    if(component.current && !component.current.contains(e.target)){
      setSuggetion(false)
    }
  }



  function showSuggetion(e){
    setSuggetion(!isSuggetion)   
  }


  function selectItem(e, item){
    let input = e.target.parentElement.parentElement.querySelector('input')
    input.value += " " + item
    onChange(input.name, input.value)
    setSuggetion(false)
  }

  function showInputHandler(e){
    setFocus(true)
    if(input){
      input.current.focus()      
    }
  }

  const handleBlur=(e)=>{
    onBlur(e)
    if(input){
      if(!input.current.value){
        setFocus(false)
      }     
    }
  }

  let groupClasses = classnames("input_group", theme && `input_group_${theme}`) 


  return (
    <div ref={component} onClick={showInputHandler} className={groupClasses}>
      <div className="input_wrapper">

        <label 
          className={[isFocused || value? 'expand_label' : 'collapse_label', error && tauched ? 'error_label' : ''].join(" ")}  
          htmlFor={name}>{label}
        </label>

        <div className="input_wrapper">
          <div ref={prevErrorRef} className={["error_message",  error && tauched ? 'show_error_message' : 'hide_error_message'].join(" ")}>{ error || lastErrorMessage  }</div>
          <input  
            ref={input} 
            name={name}
            type={type} 
            id={id} 
            value={value} 
            onBlur={handleBlur}
            className={[className, isFocused || value ? 'expand_input' : 'collapse_input'].join(" ")} 
            onChange={onChang} 
          />
        </div>

        <div onClick={showSuggetion}  className="switch_select">
          <i className={['fa fa-chevron-up', isSuggetion ? 'chevron_up': 'chevron_down'].join(" ")} aria-hidden="true"></i>
        </div>
  
        { isSuggetion && (
          <div className="suggetion_list">
            { options.map((o, i)=><li onClick={(e)=>selectItem(e, o)} className="suggetion_item" key={i} >{o}</li>) }
          </div>
        ) }
        <span className={["input_border", isFocused || value ? "expand_input_border" : "collapse_input_border"].join(' ')}></span>

       
      </div>
      
    </div>
  )
}

export default Select
